D=`pwd`
CLASSPATH=$D/bin:$D/java-cup-11b.jar:$CLASSPATH

javac -cp $CLASSPATH -g -d bin -sourcepath src src/pl0/PL0_RD.java
